#!/bin/bash
function check_config()
{
    TEMPFILE=/tmp/temp_checkmaxconnection.txt
    dev_connlimit get all|grep tap>$TEMPFILE

    A=`cat $TEMPFILE|wc -l`
    for (( i=1; i<=$A; i=i+1 ));do
        B=`cat $TEMPFILE|awk 'NR=="'$i'"{print $2}'`
        C=`cat $TEMPFILE|awk 'NR=="'$i'"{print $3}'`
        F=`cat $TEMPFILE|awk 'NR=="'$i'"{print $1}'`
        D1=$((65535*9/10))
        D2=$((200000*9/10))
        D3=$((500000*9/10))
        D4=$((800000*9/10))
        if (( 0 <= $C ))&&(( $C < $D1 ));then
            continue
        elif (( $D1 <= $C ))&&(( $C < $D2 ));then
            dev_connlimit set $F 200000
        elif (( $D2 <= $C ))&&(( $C < $D3 ));then
            dev_connlimit set $F 500000
        elif (( $D3 <= $C ));then
            dev_connlimit set $F 800000
        fi
    done
}
check_config
