#!/usr/bin/env python
# -*- coding:utf-8 -*-
import urllib2
import sys,os,json,re
import ssl
import time

reload(sys)
sys.setdefaultencoding('utf8')

if len(sys.argv) < 2:
    print "Usage:"+sys.argv[0]+" ServiceName"
    print "example:"+sys.argv[0]+" ECS"
    print "Attention:ServiceName is case sensitive!!!"
    sys.exit(255)
else:
    cloudservice=sys.argv[1]

#Global Var
hec_en=('cn-northeast-1','cn-north-3','cn-north-1','cn-north-4','cn-east-2','cn-east-3','cn-south-1','cn-south-2','cn-southwest-2','ap-southeast-1','ap-southeast-2','ap-southeast-3','af-south-1','ru-northwest-2')

#Global cancel SSL certificate verify
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

def get_token():
    accessKey='AK_3RD_CLOUDOPS_CloudMonitorTenant_IAAS_ECS'
    secretKey='w1lXtE6j1jyl3vOJ#mlxHkMvQqQtXWFw0M0fzAqx0Fo='
    scope_api='https://10.44.88.233:8443/access/v2.0/token'
    req=urllib2.Request(scope_api)
    post_data=json.dumps({"accessKey":accessKey,"secretKey":secretKey})
    req.add_header('Content-Type','application/json')
    req.add_data(post_data)
    try:
        res=urllib2.urlopen(req,timeout=10)
        output_data=json.loads(res.read())
        token=output_data["data"]["id"]
    except urllib2.URLError as e:
        #print "fail Reason(step1): ",e.reason
        token=None
    del output_data
    return token


def get_component_list(cloudservice,regioncode):
    cmdb_api='https://cmdb-api.lf.hwclouds.com/v1/cloud-cmdb/cloud-service-instance/micro-service-by-cloud-service?'
    api_instance="%scloudServiceName=%s&regionCode=%s" % (cmdb_api,cloudservice,regioncode)
    req=urllib2.Request(api_instance)
    req.add_header('Content-Type','application/json')
    req.add_header('x-open-token',token)

    try:
        res=urllib2.urlopen(req,timeout=10)
        component_list=[]
        datasrc=json.loads(res.read())["data"]
        for line in datasrc:
            component_list.append(line["microServiceName"])
    except urllib2.URLError as e:
        #print "fail Reason(step2): ",e.reason
        component_list=[]
    return  component_list



#main
token=get_token()
componentlist=[]
for rg in hec_en:
    tmplist=get_component_list(cloudservice,rg)
    componentlist=componentlist+tmplist
    time.sleep(0.5)
   
final_componentlist=list(set(componentlist))
for x in final_componentlist:
    print str(cloudservice)+':'+str(x)
