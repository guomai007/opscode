#!/usr/bin/env python
# -*- coding:utf-8 -*-
import urllib2
import sys,json
import ssl

reload(sys)
sys.setdefaultencoding('utf8')

if len(sys.argv) < 2:
    print "Usage:"+sys.argv[0]+" ipaddr1 ipaddr2 ... //ipaddr为管理IP地址，以空格分隔"
    sys.exit(255)
else:
    iplistfile=sys.argv[1]

#Global Var
#Global cancel SSL certificate verify
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

def get_token():
    accessKey='AK_3RD_CLOUDOPS_CloudMonitorTenant_IAAS_ECS'
    secretKey='w1lXtE6j1jyl3vOJ#mlxHkMvQqQtXWFw0M0fzAqx0Fo='
    scope_api='https://10.44.88.233:8443/access/v2.0/token'
    req=urllib2.Request(scope_api)
    post_data=json.dumps({"accessKey":accessKey,"secretKey":secretKey})
    req.add_header('Content-Type','application/json')
    req.add_data(post_data)
    try:
        res=urllib2.urlopen(req,timeout=10)
        output_data=json.loads(res.read())
        token=output_data["data"]["id"]
    except urllib2.URLError as e:
        #print "fail Reason(step1): ",e.reason
        token=None
    del output_data
    return token


def get_bmcIP(mgmtIP):
    cmdb_api='https://cmdb-api.lf.hwclouds.com/v1/cloud-cmdb/hosts?pageSize=100&mgmtIps='
    IPList=','.join(mgmtIP)
    api_instance="%s%s" % (cmdb_api,IPList)
    req=urllib2.Request(api_instance)
    req.add_header('Content-Type','application/json')
    req.add_header('x-open-token',token)
    ip_group={}
    try:
        res=urllib2.urlopen(req,timeout=10)
        datasrc=json.loads(res.read())["result"]
        for line in datasrc:
            key=line["ip"]
            value=line["bmcIp"]
            ip_group[key]=value
    except urllib2.URLError as e:
        #print "fail Reason(step2): ",e.reason
        pass
    return ip_group



#main
token=get_token()
iplist=sys.argv
output={}
group_iplist=[iplist[i:i+100] for i in range(0,len(iplist),100)]
for x in group_iplist:
    d=get_bmcIP(x)
    output.update(d)
print("%-15s        %-15s" % ('管理IP地址','BMC IP地址'))
for k,v in output.items():
    print("%-15s    %-15s" % (k,v))
