#!/bin/sh
sed -i '/API_COM\/bin\/check_tomcat.sh/s%^%#%' /etc/crontab
sh /opt/dcm/connect/API_COM/bin/appctl.sh stop >/dev/null 2>&1

ps -elf|grep tomcat |grep -v grep

if [ $? -eq 0 ];then
    echo 'Start Fail!'
else
    echo 'Start OK!'
fi

