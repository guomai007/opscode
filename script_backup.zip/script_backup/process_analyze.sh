#!/bin/sh
tmp1=`ps --width=150 -e -o user,pid,ppid,comm,cmd|grep -v PPID`
echo "$tmp1"|while read line ;do
    user=`echo $line|awk '{print $1}'`
    pid=`echo $line|awk '{print $2}'`
    ppid=`echo $line|awk '{print $3}'`
    comm=`echo $line|awk '{print $4}'`
    cmd=`echo $line|awk '{ for(i=1; i<=4; i++){ $i="" }; print $0 }'| sed 's/^\s*//g'`
    if [ $pid -eq 2 ];then continue ;fi
    if [ $ppid -eq 2 ];then
        is_kthread=`echo "$cmd" |grep '\[.*\]' -o`
        if [ ! -z $is_kthread ];then continue;fi
    fi
    if [ $pid -eq 1 ];then
        real_exe=`ls -l /proc/1/exe|awk '{print $NF}'`
        rpm_name=`rpm -qf $real_exe`
        cgroup_cpu='NoLimit'
        cgroup_mem='NoLimit'
        father_comm='IDIE PID0'
        echo -ne  "$comm||$cmd||$user||$rpm_name||$cgroup_cpu||$cgroup_mem||$father_comm\n"
        continue
    fi
    if [ $ppid -ne 1 ] ;then
            rpm_name='None'
            cgroup_cpu='None'
            cgroup_mem='None'
            xpid=$pid
        while true;do
            recursive_ppid=`echo "$tmp1" | awk -v xpid="$xpid" '$2==xpid {print $3}'`
            if [ $recursive_ppid -ne 1 ];then
                xpid=$recursive_ppid
            else
                last_ppid=$xpid
                father_comm=`echo "$tmp1" | awk -v last_ppid="$last_ppid" '$2==last_ppid {print $4}'`
                echo -ne  "$comm||$cmd||$user||$rpm_name||$cgroup_cpu||$cgroup_mem||$father_comm\n"
                break
            fi
        done
    else
        father_comm='systemd'
        tmp2=`ls -l /proc/$pid/exe  2> /dev/null`
        if [  $? -ne 0 ];then
            continue
        else
            real_exe=`echo "$tmp2"|awk '{print $NF}'`
            rpm_name=`rpm -qf $real_exe`
            if [ $? -ne 0 ];then rpm_name='None' ;fi
            cgroup_stat=`cat /proc/$pid/cgroup`
            cpu_dir=`echo "$cgroup_stat"|grep cpu:|awk -F: '{print $NF}'`
            mem_dir=`echo "$cgroup_stat"|grep memory:|awk -F: '{print $NF}'`
            cpu_quota_us=`cat /sys/fs/cgroup/cpu/$cpu_dir/cpu.cfs_quota_us`
            cpu_period_us=`cat /sys/fs/cgroup/cpu/$cpu_dir/cpu.cfs_period_us`
            mem_limit_bytes=`cat /sys/fs/cgroup/memory/$mem_dir/memory.limit_in_bytes`
            mem_limit_size=`echo $mem_limit_bytes|wc -c`
            if [ "$cpu_quota_us" = "-1" ];then
                cgroup_cpu='NoLimit'
            else
                cgroup_cpu_tmp=`echo "cpu_quota_us*100/cpu_period_us"|bc -l`
                cgroup_cpu=`printf "%1.f\n" $cgroup_cpu_tmp`
            fi
            if [ $mem_limit_size -eq 20 ];then
                cgroup_mem='NoLimit'
            else
                cgroup_mem_tmp=`echo "$mem_limit_bytes/1024/1024"|bc`
                cgroup_mem="${cgroup_mem_tmp}MB"
            fi
            echo -ne  "$comm||$cmd||$user||$rpm_name||$cgroup_cpu||$cgroup_mem||$father_comm\n"
        fi
    fi
done