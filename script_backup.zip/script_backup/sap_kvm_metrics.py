# -*- encoding: utf-8 -*-
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


import ast
import json
import os
import re
import subprocess
import time

from oslo_config import cfg
from oslo_log import log
from oslo_utils import timeutils

from ceilometer.compute import pollsters
from ceilometer.hw_plugins.compute.utils import utils as hw_utils
from ceilometer import sample
from ceilometer import utils


LOG = log.getLogger(__name__)
CONF = cfg.CONF

KVM_VM_METRIC = [
    cfg.StrOpt('virtualization_solution_version',
               default='FusionSphere OpenStack V100R006C20',
               help='virtualization solution version')
]

CONF.register_opts(KVM_VM_METRIC, 'kvm_vm_metric')


class KvmVmInstMetricPollster(pollsters.BaseComputePollster):
    def __init__(self):
        self.nova_client_ext = None
        self._instance_static_metrics = []
        self._host_static_metrics = {}
        self._cur_volume_info = {}
        # {"devpath":
        #          [Last_info, cur_info],
        # ...}
        self._current_speed = 0
        self._dpdk_status = None
        self._current_speed_updated = False
        self._instance_metrics = {}
        # {instance_uuid: { tap_name: [mac_address,
        #                              port_cascading_uuid,
        #                              rx_bytes,
        #                              tx_bytes]
        #                  },
        # }
        self._nic_info_cache = {}
        # {instance_uuid: { mac_address: port_cascading_uuid
        #                  },
        # }
        self._port_mapping = {}
        self._cache_vm_processing_power_consumption = {}
        self._ovs_if_str = ''
        self._last_time = None
        self._current_time = None

    @property
    def default_discovery(self):
        return "ext_metrics_discovery"

    def get_samples(self, manager, cache, resources):
        inst_resources = resources[0:-1]
        self._init_host_static_metrics(inst_resources)
        self._init_instance_metrics(resources[-1])
        self._init_ports_mapping()
        self._init_rest_items()

        vm_list = self._get_vm_list(inst_resources)

        # vm_list : [{},{}]
        # iterate make_sample
        for vm_item in vm_list:
            LOG.info("monitor instance %s", vm_item.get("instance_id"))
            tenant_id = vm_item.get('tenant_id', None)
            sample_data = self.make_sample_from_vm(
                vm_item,
                name='instance.host.info',
                volume=1,
                type=sample.TYPE_GAUGE,
                unit='instance',
                tenant_id=tenant_id
            )
            LOG.info("The sample is:%s" % sample_data)
            LOG.info('The instance metrics is:%s' % vm_item)
            yield sample_data

    def _init_instance_metrics(self, metrics):
        for metric in metrics:
            id = metric.get("instance_uuid")
            description = json.loads(metric.get("description"))
            self._instance_metrics[id] = description

    def make_sample_from_vm(self, vm_item, name,
                            volume, type, unit, tenant_id):
        # vm_item :"resource_metadata":{"instance_metrics":{"volumes":[{}]}}
        resource_metadata = self._get_metadata_from_vm_info(vm_item)
        return sample.Sample(
            name=name,
            type=type,
            unit=unit,
            volume=volume,
            user_id=None,
            project_id=tenant_id,
            resource_id=vm_item.get('instance_id', ''),
            timestamp=timeutils.utcnow().isoformat(),
            resource_metadata=resource_metadata,
            source='OpenStack',
        )

    def _get_metadata_from_vm_info(self, vm_info):
        instance_id = vm_info.get('instance_id', '')
        display_name = "%s%s" % ('server@', instance_id)
        metadata = {
            'display_name': display_name,
            'host_metrics': json.dumps(vm_info.get('instance_metrics', ""))
        }
        return metadata

    def _get_vm_list(self, resources):
        vm_list = []
        for instance in resources:
            try:
                vm_item = self._get_vm_item_metric(instance)
                vm_list.append(vm_item)
            except Exception as e:
                LOG.exception(e)
        return vm_list

    def _get_vm_item_metric(self, instance):
        # vm_item :"resource_metadata":{"instance_metrics":{"volumes":[{}]}}
        vm_item = {}
        description = self._instance_metrics.get(instance.id, "")
        if not description:
            vm_item["instance_id"] = instance.id
        else:
            vm_item["instance_id"] = description.get('cascading_uuid')
        vm_item["tenant_id"] = instance.tenant_id

        instance_metrics = self._get_instance_metrics(instance)
        vm_item["instance_metrics"] = instance_metrics

        return vm_item

    def _get_instance_metrics(self, instance):
        metrics = {}
        # flavor
        metrics['flavor'] = str(instance.flavor.get('name', ""))
        # volume metrics
        volumes = self._get_volume_metrics(instance)
        metrics["volumes"] = volumes
        # nic metrics
        nics = self._get_nic_metrics(instance)
        metrics["nics"] = nics
        # memory metrics
        mem_min, mem_max, mem_current = self._get_mem_metrics(instance)
        metrics["guaranteed_memory_assigned"] = "%.2f" % mem_min
        metrics["max_memory_assigned"] = "%.2f" % mem_max
        metrics["current_memory_assigned"] = "%.2f" % mem_current
        if mem_max == 0:
            metrics["memory_consumption"] = 0.0
        else:
            metrics["memory_consumption"] = "%.2f" % (mem_current / mem_max)
        # static metrics
        for k, v in self._host_static_metrics.items():
            metrics[k] = v
        # cpu metrics
        metrics["vm_processing_power_consumption"] = \
            self._get_vm_processing_power_consumption(instance)
        # "[CPUID:freq,CPUID:freq,...]"
        # "0:1600000,1:2000000,2:1867000,3:1733000"
        max_freq = self._get_cpupower_info()
        metrics["max_hw_frequency"] = max_freq
        metrics["current_hw_frequency"] = max_freq
        return metrics

    def _get_volume_metrics(self, instance):
        volumes = []
        description = self._instance_metrics.get(instance.id, "")
        if not description:
            return volumes
        volume_list = description.get('volumes_attached')
        if not volume_list:
            return volumes
        volumes_id_type = self._format_volumes(volume_list)
        for vol in self.inspector.inspect_hana_volumes(instance):
            devPath = vol[1]
            if len(vol) == 3:
                cascaded_id = vol[0]
                info = volumes_id_type.get(cascaded_id, "")
                cascading_id = info[0] if info else ""
                pci_address = vol[2]
                volume_wwn = ""
            else:
                cascaded_id_part = vol[0]
                cascaded_id, cascading_id = ("", "")
                for k, v in volumes_id_type.items():
                    if cascaded_id_part in k:
                        cascaded_id = k
                        cascading_id = v[0]
                pci_address = ""
                volume_wwn = self._get_scsi_vol_mapping(devPath)
            host = getattr(instance, 'OS-EXT-SRV-ATTR:host', '')
            info = volumes_id_type.get(cascaded_id)
            if not info:
                continue
            volume = self._get_volume_rate_info(devPath, cascaded_id, host)
            volume["volume_uuid"] = cascading_id
            volume["volume_type"] = info[1] if info else ""
            volume["pci_address"] = pci_address
            volume["volume_wwn"] = volume_wwn
            volumes.append(volume)

        return volumes

    def _format_volumes(self, volumes):
        format_volumes = {}
        for vol in volumes:
            cascaed_id = str(vol.get('volume_id'))
            volume_name = str(vol.get('volume_name'))
            if "@" in volume_name:
                cascading_id = volume_name.split("@")[1].strip()
            else:
                cascading_id = ""
            volume_type = vol.get('volume_type')
            format_volumes[cascaed_id] = [cascading_id, volume_type]
        return format_volumes

    def _get_scsi_vol_mapping(self, dev):
        wwn = None
        (out, __err) = utils.execute('ls', '-l', dev,
                                     run_as_root=False)
        if not out:
            LOG.info('failed to ll %s fail: %s', dev, str(__err))
        point = out.split("/dev/")[2].strip()
        cmd = 'ls -l /dev/disk/by-id/ |grep ' + point + "|grep scsi-3"
        try:
            output = subprocess.check_output(cmd, shell=True)
            out_list = output.split(" ")
            for item in out_list:
                if "scsi-3" in item:
                    wwn = item
        except subprocess.CalledProcessError as e:
            LOG.info('failed to ls -l /dev/disk/by-id/ |grep %s'
                     ' |grep scsi-3. fail: %s', point, str(e))
            return wwn
        return wwn

    def _get_volume_rate_info(self, devPath, cascaed_id, host):
        self._flush_volume_info(devPath, cascaed_id, host)
        dicDiskIoOutDetail = {'rd_ticks': None, 'wr_ticks': None,
                              "rd_ios": None, "tot_ticks": None,
                              "byte_in": None, "byte_out": None,
                              "rq_ticks": None}

        if len(self._cur_volume_info[cascaed_id]) < 2:
            return dicDiskIoOutDetail

        cur_flag, cur_rd_ticks_or_wr_sec, cur_wr_ticks, cur_rd_ios,\
        cur_wr_ios, cur_rd_sec_or_wr_ios, cur_wr_sec, cur_tot_ticks,\
        fCur_rq_ticks, cur_uptime, Cur_Time =\
            self._get_cur_volume_info(cascaed_id, 1)

        Last_flag, Last_rd_ticks_or_wr_sec, Last_wr_ticks, Last_rd_ios,\
        Last_wr_ios, Last_rd_sec_or_wr_ios, Last_wr_sec, Last_tot_ticks,\
        fLast_rq_ticks, Last_uptime, Last_Time =\
            self._get_cur_volume_info(cascaed_id, 0)

        flag = cur_flag and Last_flag

        if flag:
            fTime_stamp = Cur_Time - Last_Time
            uptime = cur_uptime - Last_uptime
            if fTime_stamp <= 0:
                LOG.debug("Cur_Time less than Last_Time."
                          "Cur_Time: %s, "
                          "Last_Time: %s" % (Cur_Time, Last_Time))
                self._cur_volume_info[cascaed_id][0] = \
                    self._cur_volume_info[cascaed_id][1]
                return dicDiskIoOutDetail
            if uptime <= 0:
                LOG.debug("cur_uptime less than Last_uptime."
                          "cur_uptime: %s, "
                          "Last_uptime: %s" % (cur_uptime, Last_uptime))
                self._cur_volume_info[cascaed_id][0] = \
                    self._cur_volume_info[cascaed_id][1]
                return dicDiskIoOutDetail
            try:

                if cur_rd_ios - Last_rd_ios != 0:
                    rd_ticks =\
                        (cur_rd_ticks_or_wr_sec - Last_rd_ticks_or_wr_sec)\
                        / abs((cur_rd_ios - Last_rd_ios))
                else:
                    rd_ticks = 0.0

                if cur_wr_ios - Last_wr_ios != 0:
                    wr_ticks = (cur_wr_ticks - Last_wr_ticks) / abs(
                        (cur_wr_ios - Last_wr_ios))
                else:
                    wr_ticks = 0.0

                if uptime != 0:
                    hz = self._get_HZ()
                    tot_ticks = abs(
                        (cur_tot_ticks - Last_tot_ticks)) / uptime * hz / 10
                    rq_ticks = (fCur_rq_ticks - fLast_rq_ticks)\
                               / uptime * hz / 1000
                else:
                    tot_ticks = 0.0
                    rq_ticks = 0.0

                if fTime_stamp != 0:
                    rd_ios = abs((cur_rd_ios - Last_rd_ios)) / fTime_stamp
                    wr_ios = abs((cur_wr_ios - Last_wr_ios)) / fTime_stamp
                    byte_in = abs((cur_wr_sec - Last_wr_sec))\
                              / 2 / fTime_stamp
                    byte_out =\
                        abs((cur_rd_sec_or_wr_ios - Last_rd_sec_or_wr_ios))\
                        / 2 / fTime_stamp
                else:
                    rd_ios = 0.0
                    wr_ios = 0.0
                    byte_in = 0.0
                    byte_out = 0.0
                dicDiskIoOutDetail['rd_ticks'] = "%.2f" % rd_ticks
                dicDiskIoOutDetail['wr_ticks'] = "%.2f" % wr_ticks
                dicDiskIoOutDetail["rd_ios"] = "%.2f" % rd_ios
                dicDiskIoOutDetail["wr_ios"] = "%.2f" % wr_ios
                dicDiskIoOutDetail["tot_ticks"] = "%.2f" % tot_ticks
                dicDiskIoOutDetail["byte_in"] = "%.2f" % byte_in
                dicDiskIoOutDetail["byte_out"] = "%.2f" % byte_out
                dicDiskIoOutDetail["rq_ticks"] = "%.2f" % rq_ticks
                # dicDiskIoOutDetail["sDiskName"] = sDiskName
            except Exception as e:
                self._cur_volume_info[cascaed_id][0] = \
                    self._cur_volume_info[cascaed_id][1]
                LOG.debug(
                    'failed to get out io info of vm disk. reason : %s ',
                    str(e))
                # LOG.debug(
                #    'failed to get out io info of vm disk %s. reason : %s ',
                #    sDiskName, str(e))

        # reset the first element of _cur_volume_info
        self._cur_volume_info[cascaed_id][0] =\
            self._cur_volume_info[cascaed_id][1]
        return dicDiskIoOutDetail

    def _get_cur_volume_info(self, cascaede_id, i):
        sign = int(i)
        flag = self._cur_volume_info[cascaede_id][sign][0]
        rd_ticks_or_wr_sec = self._cur_volume_info[cascaede_id][sign][1]
        wr_ticks = self._cur_volume_info[cascaede_id][sign][2]
        rd_ios = self._cur_volume_info[cascaede_id][sign][3]
        wr_ios = self._cur_volume_info[cascaede_id][sign][4]
        rd_sec_or_wr_ios = self._cur_volume_info[cascaede_id][sign][5]
        wr_sec = self._cur_volume_info[cascaede_id][sign][6]
        tot_ticks = self._cur_volume_info[cascaede_id][sign][7]
        rq_ticks = self._cur_volume_info[cascaede_id][sign][8]
        uptime = self._cur_volume_info[cascaede_id][sign][9]
        Time = self._cur_volume_info[cascaede_id][sign][10]

        return flag, rd_ticks_or_wr_sec, wr_ticks, rd_ios, wr_ios,\
               rd_sec_or_wr_ios, wr_sec, tot_ticks, rq_ticks, uptime, Time

    def _get_HZ(self):
        hz = os.sysconf("SC_CLK_TCK")
        if hz == -1:
            hz = 0
        return hz

    def _get_upTime(self, hz):
        uptime = 0
        (out, __err) = utils.execute('cat', '/proc/uptime',
                                     run_as_root=False)
        if not out:
            LOG.debug('failed to cat /proc/uptime %s '
                      'fail: %s' % (str(out[0]), str(__err)))
            return uptime
        data = out.split()[0]
        uptime = float(data) * hz
        return uptime

    def _flush_volume_info(self, devPath, cascaed_id, host):
        cur_volume_info = self._set_cur_volume_info(devPath, host)
        LOG.debug("cur_volume_info=" + str(cur_volume_info))

        if not cur_volume_info:
            self._cur_volume_info[cascaed_id] = []
        if not self._cur_volume_info.get(cascaed_id):
            self._cur_volume_info[cascaed_id] = [cur_volume_info]
        elif len(self._cur_volume_info[cascaed_id]) < 2:
            self._cur_volume_info[cascaed_id].append(cur_volume_info)
        else:
            self._cur_volume_info[cascaed_id][1] = cur_volume_info

    def _set_cur_volume_info(self, devpath, host):
        cur_rd_ticks_or_wr_sec = 0.0
        cur_wr_ticks = 0.0
        cur_tot_ticks = 0.0

        cur_rd_ios = 0.0
        cur_wr_ios = 0.0

        cur_rd_sec_or_wr_ios = 0.0
        cur_wr_sec = 0.0

        rp_tick = 0.0
        hz = self._get_HZ()
        cur_uptime = self._get_upTime(hz)
        cur_time = time.time()

        if devpath != '':
            # ll /dev/mapper/i-00000004-root: lrwxrwxrwx 1 root
            # root 7 Jun  5 09:24 /dev/mapper/i-00000004-root -> ../dm-5
            (out, __err) = utils.execute('ls', '-l', devpath,
                                         run_as_root=False)
            if not out:
                LOG.info('failed to ll %s fail: %s', devpath, str(__err))
                return (False, cur_rd_ticks_or_wr_sec, cur_wr_ticks,
                        cur_rd_ios, cur_wr_ios, cur_rd_sec_or_wr_ios,
                        cur_wr_sec, cur_tot_ticks, rp_tick, cur_uptime,
                        cur_time)
            devLine = out
            index = devLine.rfind('/')
            devId = devLine[index + 1:]
            if devId == '':
                LOG.info('failed to get devId,devLine is %s', devLine)
                return (False, cur_rd_ticks_or_wr_sec, cur_wr_ticks,
                        cur_rd_ios, cur_wr_ios, cur_rd_sec_or_wr_ios,
                        cur_wr_sec, cur_tot_ticks, rp_tick, cur_uptime,
                        cur_time)
            cmd = 'cat /proc/diskstats | grep ' + devId
            try:
                out = subprocess.check_output(cmd, shell=True)
            except subprocess.CalledProcessError as e:
                LOG.debug("failed to cat /proc/diskstats"
                          " | grep  %s. fail: %s" % (devId, e))
                return (False, cur_rd_ticks_or_wr_sec, cur_wr_ticks,
                        cur_rd_ios, cur_wr_ios, cur_rd_sec_or_wr_ios,
                        cur_wr_sec, cur_tot_ticks, rp_tick, cur_uptime,
                        cur_time)
            try:
                lstdata = out.split()
                cur_rd_ticks_or_wr_sec = float(lstdata[6])
                cur_wr_ticks = float(lstdata[10])
                cur_rd_ios = float(lstdata[3])
                cur_wr_ios = float(lstdata[7])
                cur_rd_sec_or_wr_ios = float(lstdata[5])
                cur_wr_sec = float(lstdata[9])
                cur_tot_ticks = float(lstdata[12])
                rp_tick = float(lstdata[13])
            except Exception as e:
                LOG.info("get cur_volume_info error,why=%s" % e)
                return (False, cur_rd_ticks_or_wr_sec, cur_wr_ticks,
                        cur_rd_ios, cur_wr_ios, cur_rd_sec_or_wr_ios,
                        cur_wr_sec, cur_tot_ticks, rp_tick, cur_uptime,
                        cur_time)
        return (True, cur_rd_ticks_or_wr_sec, cur_wr_ticks, cur_rd_ios,
                cur_wr_ios, cur_rd_sec_or_wr_ios, cur_wr_sec, cur_tot_ticks,
                rp_tick, cur_uptime, cur_time)

    def _init_host_static_metrics(self, resources):
        # init host static metrics
        if not self._host_static_metrics:
            host = getattr(resources[0], 'OS-EXT-SRV-ATTR:host', '')

            virsh_version = self._get_virsh_version(host)
            virtualization_solution_version = \
                CONF.kvm_vm_metric.virtualization_solution_version
            hardware_manufacturer, hardware_model = \
                self._get_dmidecode_system(host)
            processor_type = self._get_processor_type(host)
            number_of_cores = self._get_number_of_cores(host)
            number_of_threads_per_core = \
                self._get_number_of_threads_per_core(host)
            allocation_ratio = self._get_allocation_ratio(host)
            cpu_ratio = allocation_ratio["cpu_allocation_ratio"]
            if not allocation_ratio["ram_allocation_ratio"]\
                    or allocation_ratio["ram_allocation_ratio"] == 1.0:
                ram_allocation_ratio = 0
            else:
                ram_allocation_ratio = 1

            self._host_static_metrics["host_identifier"] = host
            self._host_static_metrics["virtualization_solution"] =\
                virsh_version
            self._host_static_metrics['virtualization_solution_version'] =\
                virtualization_solution_version
            self._host_static_metrics["hardware_manufacturer"] = \
                hardware_manufacturer
            self._host_static_metrics["hardware_model"] = hardware_model
            self._host_static_metrics["processor_type"] = processor_type
            self._host_static_metrics["number_of_cores"] = number_of_cores
            self._host_static_metrics["number_of_threads_per_core"] = \
                number_of_threads_per_core
            self._host_static_metrics["cpu_ratio"] = \
                cpu_ratio
            self._host_static_metrics["memory_over_provisioning"] = \
                ram_allocation_ratio

    def _get_cpupower_info(self):
        (out, e) = utils.execute('python', '-c',
                                 'import libuvp_compute;'
                                 'print libuvp_compute.getGlobalOpts().'
                                 'get("cpufreq")',
                                 run_as_root=True)
        if not out:
            LOG.debug("failed to get cpufreq . Error: %s" % e)
            return None
        cpupower = ast.literal_eval(out)
        if not cpupower:
            return None
        max_freq = cpupower.get("max_freq")
        if max_freq:
            max_freq = int(int(max_freq) / 1000000)
        return max_freq

    def _get_vm_processing_power_consumption(self, instance):

        if not self.\
                _cache_vm_processing_power_consumption.get(instance.id):
            self._cache_vm_processing_power_consumption[instance.id] =\
                self.inspector.inspect_hana_cpus(instance)
            return None
        (start_time, nvcpu, vcpu_info1) =\
            self._cache_vm_processing_power_consumption.get(instance.id)
        LOG.debug("start_time=%s, nvcpu=%s,"
                  " vcpu_info1=%s" % (str(start_time),
                                      str(nvcpu), str(vcpu_info1)))
        (end_time, nvcpu2, vcpu_info2) =\
            self.inspector.inspect_hana_cpus(instance)
        LOG.debug("end_time=%s, nvcpu=%s,"
                  " vcpu_info2=%s" % (str(end_time),
                                      str(nvcpu2), str(vcpu_info2)))
        test_time = (end_time - start_time).total_seconds()
        vcpu_usage = 0
        for i in range(0, nvcpu, 1):
            vcpu_usage += vcpu_info2[i][2] - vcpu_info1[i][2]
        vm_processing_power_consumption =\
            "%.2f" % (vcpu_usage / nvcpu / 1000000000 / test_time * 100)
        LOG.debug('Current vm_processing_power_consumption'
                  ' is %s, time: %s.' %
                  (str(vm_processing_power_consumption), str(end_time)))
        self._cache_vm_processing_power_consumption[instance.id] =\
            (end_time, nvcpu2, vcpu_info2)
        return vm_processing_power_consumption

    def _get_allocation_ratio(self, host):
        allocation_ratio = {}
        if not self.nova_client_ext:
            try:
                self.nova_client_ext = hw_utils.init_nova_ext_client()
            except hw_utils.GetCatalogError as err:
                LOG.debug("Init nova-ext-client failed for:%s" % err)
                raise
        allocation_ratio = \
            self.nova_client_ext.get_allocation_ratio_by_host(host)
        return allocation_ratio

    def _get_virsh_version(self, host):
        (out, e) = utils.execute('timeout', '20', 'virsh', 'version',
                                 run_as_root=True)
        if not out:
            LOG.debug("failed to get virsh version of "
                      "host %s. error: %s" % (host, e))
            return None
        if "Using API: QEMU" in out:
            virsh_version = 'kvm'
        else:
            virsh_version = 'unknown'
        return virsh_version

    def _get_dmidecode_system(self, host):
        (out, e) = utils.execute('dmidecode', '-t', 'system',
                                 run_as_root=True)
        hardware_manufacturer = ''
        hardware_model = ''
        if not out:
            LOG.debug("failed to get hardware manufacturer of "
                      "host %s. error: %s" % (host, e))
            return None
        output_list = out.split('\n')
        for i in output_list:
            if "Manufacturer" in i:
                temp = i.split(":")
                hardware_manufacturer = temp[1].strip() or ""
            if "Product Name" in i:
                temp = i.split(":")
                hardware_model = temp[1].strip() or ""
        return hardware_manufacturer, hardware_model

    def _get_processor_type(self, host):
        file = "/proc/cpuinfo"
        awk_item = "{print $4,$5,$6,$7,$8,$9,$10}"
        cmd = """cat %s|grep model | awk '%s'""" % (file, awk_item)
        try:
            out = subprocess.check_output(cmd, shell=True)
            line_list = out.strip().split("\n")
            processor_type = line_list[0] or ""
            return processor_type
        except subprocess.CalledProcessError as e:
            LOG.debug("failed to get processor type of "
                      "host %s. error: %s" % (host, e))
            return None

    def _get_number_of_cores(self, host):
        cmd = "cat /proc/cpuinfo |grep processor |wc -l"
        try:
            out = subprocess.check_output(cmd, shell=True)
            number_of_cores = out.strip() or ""
            return number_of_cores
        except subprocess.CalledProcessError as e:
            LOG.debug("failed to get number_of_cores of "
                      "host %s. error: %s" % (host, e))
            return None

    def _get_number_of_threads_per_core(self, host):
        (out, e) = utils.execute('lscpu', run_as_root=False)
        if not out:
            LOG.debug("failed to get number_of_threads_per_core of "
                      "host %s. error: %s" % (host, e))
            return None
        line_list = out.split("\n")
        for line in line_list:
            if "Thread(s) per core" in line:
                number_of_threads_per_core = \
                    line.split(":")[1].strip() or ""
                return number_of_threads_per_core

    def _get_nic_metrics(self, instance):
        nics = []
        update_cache = {}

        last_run_info = self._nic_info_cache.get(instance.id, None)
        if last_run_info is None:
            self._nic_info_cache[instance.id] = {}
        for vnic, info in self.inspector.\
                inspect_vnics_sap_kvm(instance, self._ovs_if_str):
            nic = {}
            last_info = self._nic_info_cache[instance.id].get(vnic.name, None)
            mac = vnic.mac
            if last_info is None:
                last_rx = last_tx = 0.0
                nic_name = self._get_cascading_port_uuid(instance.id, mac)
                if nic_name is None:
                    continue
            else:
                nic_name = last_info[1]
                last_rx = last_info[2]
                last_tx = last_info[3]
            nic['mac_address'] = mac
            nic['nic_name'] = nic_name
            nic['current_speed'] = self._current_speed
            nic['status'] = self._dpdk_status or "up"
            if self._last_time is not None and \
                            self._current_time is not None:
                delta = timeutils.delta_seconds(self._last_time,
                                                self._current_time)
                byte_in = (float(info.rx_bytes) - last_rx) / (delta * 1024)
                byte_out = (float(info.tx_bytes) - last_tx) / (delta * 1024)
            else:
                byte_in = 0
                byte_out = 0
            nic['byte_in'] = "%.2f" % byte_in
            nic['byte_out'] = "%.2f" % byte_out
            nics.append(nic)
            LOG.debug("vinc_mane is : %s" % vnic.name)
            LOG.debug("last_rx is %s, cur_rx is %s, byte_in is :%s" % (
                last_rx, info.rx_bytes, byte_in))
            LOG.debug("last_tx is %s, cur_tx is %s, byte_out is :%s" % (
                last_tx, info.tx_bytes, byte_out))

            update_cache[vnic.name] = [mac, nic_name, float(info.rx_bytes),
                                       float(info.tx_bytes)]
        # update cache
        self._nic_info_cache[instance.id] = update_cache

        return nics

    def _get_mem_metrics(self, instance):
        return self.inspector.inspect_hana_memory(instance)

    def _get_dpdk_off_flag(self):
        cmd = "cat /opt/uvp/evs/user_evs_config"
        out, _ = hw_utils.get_output(cmd)
        if out is None:
            return True
        if 'offload_mode=HWOFF' in out and '#offload_mode=HWOFF' not in out:
            return True
        return False

    def _get_current_speed(self):
        current_speed = 0
        try:
            dpdk_off = self._get_dpdk_off_flag()
            if dpdk_off:
                self._current_speed_updated = True
                return 0

            # get dpdk port
            cmd = "ovs-vsctl show"
            out, _ = hw_utils.get_output(cmd)
            if out is None or out == "":
                return 0

            result = []
            p_line = None
            for line in out.splitlines():
                if line.strip().startswith("Port"):
                    p_line = line.strip()
                    continue
                if line.strip() == 'type: dpdkbond' and p_line is not None:
                    result.append(p_line[5:])
                    p_line = None
            if not result:
                return 0

            # sum all speed
            re_speed = re.compile(r'.+speed.+?(\d+).+')
            ports = [p[1:-1] if p.startswith('"') else p for p in result]
            for port in ports:
                cmd_speed = "ovs-appctl dpdk-bond-slave/show %s" % port
                out, _ = hw_utils.get_output(cmd_speed)
                lines = out.splitlines()
                for line in lines:
                    match = re_speed.match(line)
                    if match is None:
                        continue
                    current_speed += int(match.group(1))

                if self._dpdk_status is not None:
                    continue
                lines.reverse()
                for line in lines:
                    if line.strip().startswith('"status"'):
                        if line.strip() == '"status": "UP",':
                            self._dpdk_status = 'UP'
                        elif line.strip() == '"status": "DOWN",':
                            self._dpdk_status = 'DOWN'
                        else:
                            self._dpdk_status = 'UNKOWN'
                        break

            self._current_speed_updated = True
            return current_speed
        except Exception as e:
            LOG.exception(e)
            return 0

    def _get_cascading_port_uuid(self, inst_uuid, mac):
        try:
            uuid = self._port_mapping[inst_uuid][mac]
        except Exception:
            return None
        return uuid

    def _init_ports_mapping(self):
        self._port_mapping = {}

        for inst_id, desp_dict in self._instance_metrics.iteritems():
            if self._port_mapping.get(inst_id, None) is None:
                self._port_mapping[inst_id] = {}
            ports = desp_dict['ports_attached']
            if not ports:
                continue
            for port in ports:
                mac = port.get('mac_address', None)
                name = port.get('port_name', None)
                if mac is None:
                    continue
                if name is None or not name.startswith('port@'):
                    continue

                self._port_mapping[inst_id][mac] = name[5:]

    def _init_rest_items(self):
        if not self._current_speed_updated:
            self._current_speed = self._get_current_speed()

        self._ovs_if_str = self._get_ovs_if_str()
        if self._current_time is not None:
            self._last_time = self._current_time
        self._current_time = timeutils.utcnow()

    def _get_ovs_if_str(self):
        cmd = "ovs-vsctl list interface"
        out, _ = hw_utils.get_output(cmd)
        if out is None:
            return ''

        return out.replace('\n', ' ')
