import sys

from oslo_config import cfg
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker



nova_conductor_conf = '/etc/nova/nova-compute.conf'
database_connect = cfg.StrOpt('connection', help='database connection')
CONF = cfg.CONF
CONF(default_config_files=[nova_conductor_conf])
CONF.register_opt(database_connect, group='database')


def main():
    aggregate_number = raw_input("input aggregate number:")

    session = None
    engine = create_engine(CONF.database.connection)
    db_session = sessionmaker(bind=engine)
    try:
        s = """select f.host,f.VCPUS as cpu, f.VCPUS_USED as cpu_used, f.MEMORY_MB as mem,f.MEMORY_MB_USED as mem_used,f.RUNNING_VMS as vms,g.disabled
from
(select HOST,AGGREGATE_ID from AGGREGATE_HOSTS where deleted=0 and AGGREGATE_ID='%s')e
left outer join
(select host,VCPUS, MEMORY_MB, VCPUS_USED,MEMORY_MB_USED,RUNNING_VMS
from compute_nodes where deleted=0)f
on e.host=f.host
join(
select HOST,disabled from services where deleted=0 and topic='compute'
)g
on e.host=g.host
;"""% aggregate_number
        result  = engine.execute(s)
        print "host,vcpu,vcpu_used,mem_mb,mem_mb_used,vms,disabled"
        for row in result:
            print row
    except Exception as e:
        if session:
            session.rollback()
        print("query failed, reason: %s." % e)
    finally:
        if session:
            session.close()
        db_session, engine = None, None


if __name__ == '__main__':
    main()
