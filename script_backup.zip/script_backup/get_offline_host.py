#!/usr/bin/env python
# -*- coding:utf-8 -*-
import urllib2
import sys,os,json,re
import ssl
import time

reload(sys)
sys.setdefaultencoding('utf8')

if len(sys.argv) < 2:
    print "Usage:"+sys.argv[0]+" MicroServiceName"
    print "example:"+sys.argv[0]+" API_COM"
    print "Attention:MicroServiceName is case sensitive!!!"
    sys.exit(255)
else:
    microservice=sys.argv[1]

#Global Var
hec_cn=('华北-北京三','东北-大连','华北-北京一','华北-北京四','华东-上海二','华东-上海一','华南-广州','华南-深圳','西南-贵阳一','亚太-香港','亚太-曼谷','亚太-新加坡','非洲-约翰内斯堡','俄罗斯-莫斯科二')
#hec_en=('cn-northeast-1','cn-north-3','cn-north-1','cn-north-4','cn-east-2','cn-east-3','cn-south-1','cn-south-2','cn-southwest-2','ap-southeast-1','ap-southeast-2','ap-southeast-3','af-south-1','ru-northwest-2'）

#Global cancel SSL certificate verify
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

def get_token():
    accessKey='AK_3RD_CLOUDOPS_CloudMonitorTenant_IAAS_ECS'
    secretKey='w1lXtE6j1jyl3vOJ#mlxHkMvQqQtXWFw0M0fzAqx0Fo='
    scope_api='https://10.44.88.233:8443/access/v2.0/token'
    req=urllib2.Request(scope_api)
    post_data=json.dumps({"accessKey":accessKey,"secretKey":secretKey})
    req.add_header('Content-Type','application/json')
    req.add_data(post_data)
    try:
        res=urllib2.urlopen(req,timeout=10)
        output_data=json.loads(res.read())
        token=output_data["data"]["id"]
    except urllib2.URLError as e:
        #print "fail Reason(step1): ",e.reason
        token=None
    del output_data
    return token


def get_app_offline_hostlist(component,regionname):
    post_data={"componentName":component,"regionName":regionname,"pageSize":500,"instanceStatus":"offline"}
    ret=[]
    hostlist={}
    def call_api(post):
        cmdb_api='https://cmdb-api.lf.hwclouds.com/v2/cloud-cmdb/service-instance-list'
        req=urllib2.Request(cmdb_api,json.dumps(post,ensure_ascii=False))
        req.add_header('Content-Type','application/json')
        req.add_header('x-open-token',token)
        try:
            res=urllib2.urlopen(req,timeout=10)
            datasrc=json.loads(res.read())["result"]
        except urllib2.URLError as e:
            datasrc=[]
        return datasrc
    while True:
        tmp=call_api(post_data)
        if len(tmp) == 500:
            last_host_serviceInstanceId=tmp[-1]["serviceInstanceId"]
            post_data["lastPageMaxInstanceId"]=str(last_host_serviceInstanceId)
            ret=ret+tmp
        else:
            ret=ret+tmp
            break
    for x in ret:
        key=x["hostIp"]
        value=x["hostRegionName"]
        hostlist[key]=value
    return hostlist        

def get_host_lifestatus(*omips):
    pass


#main
token=get_token()
for rg in hec_cn:
    hostlist=get_app_offline_hostlist(microservice,rg)
    for k,v in  hostlist.items():
        print microservice+","+k+","+v
