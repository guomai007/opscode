#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from oslo_config import cfg
from nova import cache_utils
from oslo_utils import timeutils


def memcache_connet_check():

    CONF = cfg.CONF
    CONF(['--config-file', '/etc/nova/nova-api.conf'])

    start = timeutils.utcnow()
    client = cache_utils.get_client()
    client.set('a', 'b')
    str_value = client.get('a')
    if str_value is None:
        return None

    end = timeutils.utcnow()
    elapsed = timeutils.delta_seconds(start, end)*1000
    return elapsed


def main():
    data = memcache_connet_check()
    if data:
        print "==nova_memcache_connect_check \nelapsed_time=" + str(data)
    else:
        print "==nova_memcache_connect_check \nelapsed_time=-1"
        return -1

if __name__ == "__main__":
    sys.exit(main())
