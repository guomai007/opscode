#!/usr/bin/python
# -*- coding:UTF-8 -*-
import json
import sys
import ConfigParser
cmd_lib_path = "/opt/cloud/services/nova-compute/venv/lib/python2.7/site-packages"
if cmd_lib_path not in sys.path:
    sys.path.append(cmd_lib_path)
from FSSecurity import crypt
from remote_executor.remote_utils import RemoteDriverManager

#Global Var
config=ConfigParser.SafeConfigParser()
config.read('/etc/offload-config.cfg')
cmd_server_host=config.get('DEFAULT','mgmt_address_x86')
cmd_server_port=int(config.get('DEFAULT','cmd_server_port'))
cmd_client_type='tcp'
cmd_ca_cert='/etc/FSSecurity/server-cert/nova-compute_ca.crt'
cmd_encrypted_pass='N8296FGj0gDK1OA8djBQ50u/7CZvJ+RfE2qNhiGICE8='

def get_cmd_client():
    cmd_password = crypt.decrypt(cmd_encrypted_pass)
    client_mgr = RemoteDriverManager([cmd_server_host],
                                     cmd_server_port, cmd_client_type,
                                     cmd_password, cmd_ca_cert)
    client_mgr.remote_driver_register()
    cmd_client = client_mgr.get_driver(cmd_server_host)
    return cmd_client


def getstatusoutput(cmd):
    rootcmd="sudo cmd-server-rootwrap /etc/cmd-server/nova-rootwrap.conf sh -c '%s'" % cmd
    cmd_client = get_cmd_client()
    return cmd_client.getstatusoutput(rootcmd)

def usage():
    print("""
Usage: %s command
参数说明: command [需要执行的命令,请使用引号包含,命令执行权限为root,请谨慎执行!!!]
使用样例: python %s "ls /home/fsp"
""" % (sys.argv[0],sys.argv[0]))

if __name__ == '__main__':
    if len(sys.argv) != 2:
        usage()
        sys.exit(1)
    cmd = sys.argv[1]
    ret, out = getstatusoutput(cmd)
    print out
    sys.exit(ret)
