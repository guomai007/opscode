#!/bin/sh
num=0
cat os_run_host.txt |while read line ;do
    uptime=`echo "$line" |grep days |awk -F',' '{print $1}'|awk '$1>=720'`
    if [  "$uptime" != '' ];then 
        field_last=`echo "$line"|awk -F',' '{print $NF}'`
        if echo "$field_last" |grep -w cna >/dev/null ; then 
            microservice=xen_cna 
        elif echo "$filed_last"|grep -w cascaded-nova-compute >/dev/null ;then 
            microservice=kvm_cna
        else 
            microservice=None
        fi
        ip=`echo "$line" |awk -F',' '{print $2}'`
        region=`echo "$line" |awk -F',' '{print $3}'`
        /bin/echo -ne "$ip\t$region\t$microservice\n"
    fi 
num=`echo "$num+1"|bc`
done

