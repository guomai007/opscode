#!/usr/bin/python
import time

exlist=[]
#fd=open('exclude_alarm')
fd=open('exclude_metric')
for x in fd.readlines():
    exlist.append(x.strip())
fd.close()

fd=open('gblog')
for x in fd.readlines():
    lesslist=[]
    morelist=[]
    lista=x.strip().split(':')
    region=lista[0]
    microservice=lista[1]
    alarm_less_list=lista[2].split(',')
    for z in alarm_less_list:
        if z in exlist:
            lesslist.append(z)
    alarm_more_list=lista[3].split(',')
    for z in alarm_more_list:
        if z in exlist:
            morelist.append(z)
    less_str=','.join(lesslist)
    more_str=','.join(morelist)
    if less_str or more_str:
        print region+':'+microservice+':'+less_str+':'+more_str
