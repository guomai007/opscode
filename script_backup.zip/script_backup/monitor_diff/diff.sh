#!/bin/sh

##diff alarm
#for region in `cat alarm_error |awk '{print $1}'|sort -u`;do
#     for microservice in `grep -w $region alarm_error |awk '{print $2}'`;do
#         grep "$microservice:" baseline.txt|awk -F: '{print $3}'|tr ',' '\n'|sort -u  >/tmp/baseline
#         if [ ! -s /tmp/baseline ];then echo "$region:$microservice:None:None" ;continue ;fi
#         grep -w $region alarm_error |grep -w $microservice | awk '{print $3}'|tr ',' '\n'|sort -u > /tmp/target
#         diffdata=`diff /tmp/target /tmp/baseline`
#         less=`echo "$diffdata"|grep '^>' |awk '{print $2}' | sed ':a;N;s/\n/,/;ta'`
#         more=`echo "$diffdata"|grep '^<' |awk '{print $2}' | sed ':a;N;s/\n/,/;ta'`
#        /bin/echo -ne "$region:$microservice:$less:$more\n" 
#      done
#done


##diff metric
for region in `cat metric_error |awk '{print $1}'|sort -u`;do
     for microservice in `grep -w $region metric_error |awk '{print $2}'`;do
         grep "$microservice:" baseline.txt|awk -F: '{print $2}'|tr ',' '\n'|sort -u  >/tmp/baseline
         if [ ! -s /tmp/baseline ];then echo "$region:$microservice:None:None" ;continue ;fi
         grep -w $region metric_error |grep -w $microservice | awk '{print $3}'|tr ',' '\n'|sort -u > /tmp/target
         diffdata=`diff /tmp/target /tmp/baseline`
         less=`echo "$diffdata"|grep '^>' |awk '{print $2}' | sed ':a;N;s/\n/,/;ta'`
         more=`echo "$diffdata"|grep '^<' |awk '{print $2}' | sed ':a;N;s/\n/,/;ta'`
        /bin/echo -ne "$region:$microservice:$less:$more\n" 
      done
done
