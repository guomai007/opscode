#!/bin/sh
om_ip=$(ip addr show dev external_om|grep -w inet|awk '{print $2}')


###injection
#iptables -A OUTPUT -s $om_ip -p icmp -j DROP
###recovery
#iptables -D OUTPUT -s $om_ip -p icmp -j DROP
