#!/bin/sh
sh /opt/dcm/connect/API_COM/bin/appctl.sh start  >/dev/null 2>&1
sed -i '/API_COM\/bin\/check_tomcat.sh/s%^#*%%' /etc/crontab

ps -elf|grep tomcat|grep -v grep
if [ $? -eq 0 ];then
    echo 'Start OK!'
else
    echo 'Start Fail!'
fi
