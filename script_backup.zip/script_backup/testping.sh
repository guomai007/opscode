#!/bin/sh
rm -f /tmp/ping_ok /tmp/ping_fail
for i in `cat ignore_ip.txt` ;do
nohup ping -n 3 -w 1 $i >/dev/null 2>&1  && echo $i >> /tmp/ping_ok &
nohup ping -n 3 -w 1 $i >/dev/null 2>&1  || echo $i >> /tmp/ping_fail &
done
